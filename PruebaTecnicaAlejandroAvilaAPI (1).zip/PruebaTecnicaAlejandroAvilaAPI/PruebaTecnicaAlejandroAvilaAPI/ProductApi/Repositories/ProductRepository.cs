﻿using Microsoft.EntityFrameworkCore;
using ProductApi.Models;

namespace ProductApi.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductContext _context;

        public ProductRepository(ProductContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Product>> GetProductsByState(bool isDefective)
        {
            return await _context.Products
                                 .Where(p => p.IsDefective == isDefective && p.Quantity > 0)
                                 .ToListAsync();
        }

        public async Task EnterProduct(int id, int quantity)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                product.Quantity += quantity;
                await _context.SaveChangesAsync();
            }
        }

        public async Task AddProduct(Product product)
        {
            _context.Products.Add(product);
            await _context.SaveChangesAsync();
        }

        public async Task RemoveProduct(int id, int quantity)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null && product.Quantity >= quantity)
            {
                product.Quantity -= quantity;
                await _context.SaveChangesAsync();
            }
        }

        public async Task MarkDefective(int id, bool defective)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                product.IsDefective = defective;
                await _context.SaveChangesAsync();
            }
        }

        public async Task<Product> GetProductById(int id)
        {
            return await _context.Products.FirstOrDefaultAsync(p => p.Id == id);
        }

        public async Task EditProductById(int id, string name, string type, bool isDefective, int quantity)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                product.Name = name;
                product.Type = type;
                product.IsDefective = isDefective;
                product.Quantity = quantity;
                await _context.SaveChangesAsync();
            }
        }
    }

}
