﻿using ProductApi.Models;

namespace ProductApi.Repositories
{
    public interface IAuthService
    {
        UserLogin Authenticate(string username, string password);
    }

    public class AuthService : IAuthService
    {
        public UserLogin Authenticate(string username, string password)
        {
            var user = UserStore.Users.SingleOrDefault(x => x.Username == username && x.Password == password);

            if (user == null)
                return null;
            return user;
        }
    }
}
