﻿using ProductApi.Models;

namespace ProductApi.Repositories
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetProductsByState(bool isDefective);
        Task AddProduct(Product product);
        Task EnterProduct(int id, int quantity);
        Task RemoveProduct(int id, int quantity);
        Task MarkDefective(int id, bool defective);
        Task<Product> GetProductById(int id);
        Task EditProductById(int id, string name, string type, bool isDefective, int quantity);
    }
}
