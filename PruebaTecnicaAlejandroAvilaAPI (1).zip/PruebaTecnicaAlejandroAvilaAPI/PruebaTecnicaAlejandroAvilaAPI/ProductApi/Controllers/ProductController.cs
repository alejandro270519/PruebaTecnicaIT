﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductApi.Models;
using ProductApi.Repositories;

namespace ProductApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepository;

        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpGet("listByState/{isDefective}")]
        public async Task<IActionResult> GetProductsByState(bool isDefective)
        {
            try
            {
                var products = await _productRepository.GetProductsByState(isDefective);
                return Ok(products);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al obtener productos: {ex.Message}");
            }
        }

        [HttpGet("GetProductById/{id}")]
        public async Task<ActionResult<Product>> GetProductById(int id)
        {
            try
            {
                var product = await _productRepository.GetProductById(id);
                return product;
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al obtener productos: {ex.Message}");
            }
        }

        [HttpPost("EditProductById/{id}/{name}/{type}/{isDefective}/{quantity}")]
        public async Task<ActionResult<Product>> EditProductById(int id, string name, string type, bool isDefective, int quantity)
        {
            try
            {
                await _productRepository.EditProductById(id, name, type, isDefective, quantity);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al intentar editar el producto: {ex.Message}");
            }
        }

        [HttpPost("AddProduct")]
        public async Task<IActionResult> AddProduct(Product product)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _productRepository.AddProduct(product);
                return CreatedAtAction(nameof(GetProductsByState), new { isDefective = product.IsDefective }, product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al intentar agregar el producto: {ex.Message}");
            }
        }

        [HttpPost("removeOneProduct/{quantity}/{id}")]
        public async Task<IActionResult> RemoveProduct(int id, int quantity)
        {
            try
            {
                var product = await _productRepository.GetProductById(id);
                if (product == null)
                {
                    return NotFound($"No se encontró el producto con ID {id}");
                }

                if (product.Quantity < quantity)
                {
                    return BadRequest($"No hay suficientes unidades en stock para eliminar {quantity} unidades del producto.");
                }

                await _productRepository.RemoveProduct(id, quantity);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al intentar eliminar el producto: {ex.Message}");
            }
        }

        [HttpPost("enterProduct/{quantity}/{id}")]
        public async Task<IActionResult> EnterProduct(int id, int quantity)
        {
            try
            {
                await _productRepository.EnterProduct(id, quantity);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al intentar ingresar el producto: {ex.Message}");
            }
        }

        [HttpPatch("MarkDefective/{id}")]
        public async Task<IActionResult> MarkDefective(int id, bool defective)
        {
            try
            {
                await _productRepository.MarkDefective(id, defective);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al intentar marcar el producto como defectuoso: {ex.Message}");
            }
        }
    }
}
