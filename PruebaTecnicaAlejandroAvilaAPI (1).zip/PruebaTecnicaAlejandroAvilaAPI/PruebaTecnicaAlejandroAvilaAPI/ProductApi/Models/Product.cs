﻿namespace ProductApi.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }  // Elaborado a mano, Elaborado a mano y máquina
        public bool IsDefective { get; set; }
        public int Quantity { get; set; }
    }
}
