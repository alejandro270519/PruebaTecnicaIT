﻿namespace ProductApi.Models
{
    public static class UserStore
    {
        // Lista estática de usuarios para pruebas
        public static List<UserLogin> Users = new List<UserLogin>
    {
        new UserLogin { Username = "admin", Password = "123"},
        new UserLogin { Username = "user", Password = "123"}
    };
    }
}
