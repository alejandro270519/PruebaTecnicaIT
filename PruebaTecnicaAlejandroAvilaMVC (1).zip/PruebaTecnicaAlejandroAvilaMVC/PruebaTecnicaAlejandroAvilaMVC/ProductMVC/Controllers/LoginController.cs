﻿using Microsoft.AspNetCore.Mvc;

namespace ProductMVC.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
